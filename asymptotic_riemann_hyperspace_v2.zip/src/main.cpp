#include <iostream>
#include <vector>
#include <cmath>
#include <complex>
#include <fstream>
#include <cstdint>
#include <algorithm>
#include <iomanip>

struct ExtendedPrimeNode4D {
    uint64_t prime;
    int16_t a, b, c, d;
    double phase_r;
    double phase_i;
};

struct MertensDrift4D {
    double cumulative_x = 0.0;
    double cumulative_y = 0.0;
    double cumulative_z = 0.0;
    double cumulative_w = 0.0;

    double compute_net_displacement() const {
        return std::sqrt(cumulative_x * cumulative_x + 
                         cumulative_y * cumulative_y + 
                         cumulative_z * cumulative_z + 
                         cumulative_w * cumulative_w);
    }
};

bool decompose_four_square(uint64_t p, int16_t& a, int16_t& b, int16_t& c, int16_t& d) {
    int64_t max_a = static_cast<int64_t>(std::sqrt(p));
    for (int64_t ta = max_a; ta >= 0; --ta) {
        int64_t rem_a = p - (ta * ta); if (rem_a < 0) continue;
        int64_t max_b = static_cast<int64_t>(std::sqrt(rem_a));
        for (int64_t tb = max_b; tb >= 0; --tb) {
            int64_t rem_b = rem_a - (tb * tb); if (rem_b < 0) continue;
            int64_t max_c = static_cast<int64_t>(std::sqrt(rem_b));
            for (int64_t tc = max_c; tc >= 0; --tc) {
                int64_t rem_c = rem_b - (tc * tc);
                int64_t td = static_cast<int64_t>(std::round(std::sqrt(rem_c)));
                
                if (ta * ta + tb * tb + tc * tc + td * td == p) {
                    int16_t coords[4] = { static_cast<int16_t>(ta), static_cast<int16_t>(tb), 
                                          static_cast<int16_t>(tc), static_cast<int16_t>(td) };
                    std::sort(coords, coords + 4, std::greater<int16_t>());
                    a = coords[0]; b = coords[1]; c = coords[2]; d = coords[3];
                    return true;
                }
            }
        }
    }
    return false;
}

int main() {
    const std::vector<double> zeta_gammas = {14.134725141734693, 21.022039638771555, 25.010857580145688};
    std::vector<uint64_t> test_primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 43, 47, 53};
    
    MertensDrift4D standard_drift;
    MertensDrift4D optimized_drift;
    
    std::cout << "[OPTIMIZED ENGINE Matrix Optimization Running...]" << std::endl;
    std::cout << std::setw(6) << "Prime" << " | " << std::setw(12) << "Std Drift" << " | " << std::setw(12) << "Opt Drift" << " | " << std::setw(12) << "Bound" << " | Status" << std::endl;
    
    for (uint64_t p : test_primes) {
        int16_t a = 0, b = 0, c = 0, d = 0;
        if (decompose_four_square(p, a, b, c, d)) {
            double log_p = std::log(static_cast<double>(p));
            double sum_cos = 0.0, sum_sin = 0.0;
            for (double gamma : zeta_gammas) {
                sum_cos += std::cos(gamma * log_p);
                sum_sin += std::sin(gamma * log_p);
            }
            double phase_r = sum_cos / zeta_gammas.size();
            double phase_i = sum_sin / zeta_gammas.size();
            
            // Standard Uncalibrated accumulation
            standard_drift.cumulative_x += a * phase_r;
            standard_drift.cumulative_y += b * phase_i;
            standard_drift.cumulative_z += c * phase_r;
            standard_drift.cumulative_w += d * phase_i;
            
            // Gauge-Orbit Optimization Optimization Check
            double best_step_drift = 1e100;
            int16_t best_a = a, best_b = b, best_c = c, best_d = d;
            int16_t signs[2] = {-1, 1};
            
            for (int16_t sa : signs) {
                for (int16_t sb : signs) {
                    for (int16_t sc : signs) {
                        for (int16_t sd : signs) {
                            double tx = optimized_drift.cumulative_x + (a * sa) * phase_r;
                            double ty = optimized_drift.cumulative_y + (b * sb) * phase_i;
                            double tz = optimized_drift.cumulative_z + (c * sc) * phase_r;
                            double tw = optimized_drift.cumulative_w + (d * sd) * phase_i;
                            double td = std::sqrt(tx*tx + ty*ty + tz*tz + tw*tw);
                            if (td < best_step_drift) {
                                best_step_drift = td;
                                best_a = a * sa; best_b = b * sb; best_c = c * sc; best_d = d * sd;
                            }
                        }
                    }
                }
            }
            
            optimized_drift.cumulative_x += best_a * phase_r;
            optimized_drift.cumulative_y += best_b * phase_i;
            optimized_drift.cumulative_z += best_c * phase_r;
            optimized_drift.cumulative_w += best_d * phase_i;
            
            double bound = std::sqrt(static_cast<double>(p));
            double opt_d = optimized_drift.compute_net_displacement();
            
            std::cout << std::setw(6) << p << " | "
                      << std::setw(12) << std::fixed << std::setprecision(4) << standard_drift.compute_net_displacement() << " | "
                      << std::setw(12) << opt_d << " | "
                      << std::setw(12) << bound << " | "
                      << (opt_d <= bound ? "SAFE" : "OVER") << std::endl;
        }
    }
    return 0;
}
